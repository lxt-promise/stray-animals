"""
喵园 CatCampus 自建识别服务。

对外只有一个核心接口 POST /v1/recognize —— 它返回的字段结构与云函数
cloudfunctions/catcampus/lib/vision.js 的契约完全一致，所以接上之后前端零改动。

下游需要在云函数的环境变量里配：
    AI_ENDPOINT = https://ai.yourdomain.com/v1/recognize
    AI_TOKEN    = 与服务端 API_TOKEN 相同
"""
from __future__ import annotations

import logging
import os
import time
from typing import List, Optional

import numpy as np
from fastapi import Depends, FastAPI, Header, HTTPException
from pydantic import BaseModel, Field

from . import config, index_store, media
from . import attrs as attr_labels
from .engine import get_engine, l2

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
log = logging.getLogger("catcampus")

# 余弦相似度 → 0~99 分的映射区间。
#
# 这两个数字不是拍脑袋定的，是用真实猫照片实测标定的（tools/_realcat_probe.py）：
#     同一只猫 + 旋转/翻转变换 : 0.960 ~ 0.996
#     不同猫之间              : 0.745 ~ 0.926
#     猫 vs 完全无关的图片     : 0.509 ~ 0.551
# 取 SIM_LOW=0.70（略高于无关图上限）让噪声彻底归零，
# 取 SIM_HIGH=0.96（略低于同猫下限）让“确凿匹配”拿满分。
# 早期版本用 0.40/0.85，导致任意两只猫都打满 99 分 —— 检索形同失效。
# 余弦 → 展示分的映射区间（v2=CLS 特征下按 scripts/probe_pool_preprocess.py 实测校准）：
# CLS 特征的实测分布：不同猫（类间）≤ ~0.76，同一只猫不同构图（类内）~0.78-0.85，同一张图 1.0。
# 取 SIM_LOW=0.75（略高于类间上限）让不同猫的分数归零，
# 取 SIM_HIGH=0.90（类内中上段）让"确凿匹配"拿满分 —— 禁止再出现 99%/97% 贴脸。
SIM_LOW = 0.75
SIM_HIGH = 0.90

# Top1 与次名的相似度差小于该值时，认为“分不出来”，压低置信度而不是硬判。
# v2=CLS 特征下类内-类间天然间隔约 0.1（实测），0.05 取其一半作为「拉不开差距」线
GAP_CLEAR = 0.05

app = FastAPI(title="CatCampus Vision", version="1.0.0")


# ---------------- 鉴权 ----------------
def authorize(authorization: str = Header(default="")) -> None:
    # ⚠️ 空 token 绝不能「对外开放」：识别服务多为公网可达的云托管实例，
    # 未配 token 等于任何人都能调 build-index 清空特征库、白嫖推理算力。
    # 早期写法 `if not config.API_TOKEN: return` 正是这个洞。
    if not config.API_TOKEN:
        raise HTTPException(status_code=503, detail="服务未配置 API_TOKEN（请在环境变量中设置）")
    if authorization != f"Bearer {config.API_TOKEN}":
        raise HTTPException(status_code=401, detail="invalid token")


# ---------------- 数据模型 ----------------
class CatRef(BaseModel):
    id: str
    name: str = ""
    pattern: str = ""
    color: str = ""
    photos: List[str] = Field(default_factory=list)   # 必须是可直接下载的 https 临时链接


class RecognizeReq(BaseModel):
    url: str = ""                 # 主图（图片走这条）
    videoUrl: str = ""            # 视频本体链接，用于真抽帧
    fileId: str = ""
    type: str = "image"
    frames: int = 1
    schoolId: str = ""
    cats: List[CatRef] = Field(default_factory=list)


class EmbedReq(BaseModel):
    url: str
    detect: bool = True


# ---------------- 工具 ----------------
def to_grade(sim: float) -> int:
    """把余弦相似度压成 0~99 的展示分。
    必须先判 finite：NaN 是 truthy，max/min 都拦不住，
    round(NaN)=NaN → int(NaN) 抛 ValueError，整个识别请求 500。"""
    if not np.isfinite(sim):
        return 0
    v = (sim - SIM_LOW) / (SIM_HIGH - SIM_LOW) * 100
    return int(max(0.0, min(99.0, round(v))))


def _ensure_index_inner(cats: List[CatRef], school_id: str, limit: int,
                        skip_ids: Optional[set] = None,
                        budget_ms: int = 0) -> int:
    """冷启动补库，返回本次真正入库的猫数。

    ⚠️ 只有「带 photos 的猫」才会被建库（`if not c.photos: continue`）。
    云函数默认只送轻量 cats（不带 photos），所以正常档案的向量要靠
    `/v1/index/build` 或识别热路径的 pendingPhotos 增量补。

    ⚠️ budget_ms > 0 时是**硬预算**：每建一只就检查剩余时间，超了立刻收工返回。
    这个参数是为识别热路径准备的 —— 云函数给 AI 的窗口只有 1800ms，
    一次请求如果顺手补十几只猫（每只下载 15s 超时上限 + 推理），
    会把整个响应拖到几十秒（现场实测 78s），云函数必然超时降级。
    补库是「锦上添花」，绝不能拖垮当次识别 —— 没补完的下次接着补，幂等。
    """
    eng = get_engine()
    deadline = (time.time() + budget_ms / 1000.0) if budget_ms > 0 else None
    built = 0
    for c in cats:
        if built >= limit:
            break
        if not c.photos:
            continue
        if skip_ids and c.id in skip_ids:
            continue
        if deadline is not None and time.time() >= deadline:
            log.info("补库预算用尽（已建 %d 只），剩余交给下次/定时任务", built)
            break
        if index_store.get(c.id) is not None:
            continue
        im = media.fetch_image(c.photos[0])
        if im is None:
            continue
        emb, _, _, _, _ = eng.features(im)
        index_store.put(c.id, school_id, emb, source="bootstrap")
        built += 1
    if built:
        log.info("冷启动补库 %d 只", built)
    return built


def ensure_index(cats: List[CatRef], school_id: str, limit: int = 40,
                 skip_ids: Optional[set] = None, budget_ms: int = 0) -> int:
    """冷启动补库：本地特征库里没有的猫，用 Payload 带来的照片链接算出来并保存。

    限流的目的是防止首次上线时被 200 只猫的下载请求拖垮；跑过一次 /v1/index/build 之后
    基本不会走到这里。

    补库是「尽力而为」的副作用：任何异常都只记日志，绝不能让一次识别请求 500。
    skip_ids：**不要传「本次识别的那只猫」** —— req.cats 是按全库顺序排的，
    cats[0] 跟本次上传的照片无关。早期这么传过，结果全库第一只猫永远补不进库。
    budget_ms：识别热路径传一个硬预算（见 _ensure_index_inner 的注释）。
    """
    try:
        return _ensure_index_inner(cats, school_id, limit, skip_ids, budget_ms)
    except Exception as e:  # noqa: BLE001 —— 见 docstring
        log.error("冷启动补库失败（本次识别可能缺少候选）: %s: %s", type(e).__name__, e)
        return 0


def index_health(school_id: str = "") -> dict:
    """特征库健康快照：后端异常不冒泡，降级成字段返回。

    特征库是**可再生数据**，它挂了不该让整个接口 500 ——
    健康检查 500 会被平台判成实例不健康、反复重启，故障反而更难查。
    降级约定：indexed = -1 表示取不到，indexError 带原因。
    """
    try:
        return {"indexed": index_store.count(school_id),
                "indexBackend": index_store.BACKEND_NAME}
    except Exception as e:  # noqa: BLE001 —— 见 docstring
        err = "%s: %s" % (type(e).__name__, e)
        log.error("特征库后端不可用（识别将无候选）: %s", err)
        return {"indexed": -1, "indexBackend": index_store.BACKEND_NAME, "indexError": err}


def search(query: np.ndarray, cats: List[CatRef], school_id: str, top_n: int = 5):
    """特征库检索。返回 (候选列表, 诊断信息)。

    ⚠️ 诊断信息里的 `indexed` / `ids` 是**上游必须消费**的，不是调试附赠品：
    云函数用它决定「哪些猫可以标记为已入库」（见 vision.js markIndexed）。
    早期只在识别成功后无条件标记全部——服务端补库失败时那些猫被误标，
    从此再也不会送照片，向量永久缺失，表现就是「库里有 4 只猫但只能认出 1 只」。

    候选过滤：相似度低于 config.MIN_SIM 的猫直接丢弃。
    没有阈值时，库里只有 1 只猫就必然返回那 1 只（哪怕 0%），
    界面会把它当 Top1 结论展示 —— 这是「上传白猫返回小黑」的直接成因。
    """
    info = {"indexed": 0, "ids": [], "dropped": 0, "bankReadError": ""}
    try:
        bank = index_store.load(school_id)
    except Exception as e:  # noqa: BLE001 —— 特征库挂了只降级为「无候选」
        log.error("特征库读取失败，本次检索无候选: %s: %s", type(e).__name__, e)
        info["bankReadError"] = "%s: %s" % (type(e).__name__, e)
        return [], info
    if not bank:
        return [], info

    ids = list(bank.keys())
    info["indexed"] = len(ids)
    info["ids"] = ids
    vecs = [np.asarray(bank[i], dtype=np.float32).reshape(-1) for i in ids]
    if not vecs:
        return [], info
    # 维度一致性：更换/调整 ReID 模型、或建库中途部分猫失败残留旧向量时，
    # np.stack 会抛 "all input arrays must have the same shape" → 识别全 500。
    # 这里按多数维度过滤不匹配项并告警，保证服务不塌。
    dim = vecs[0].shape[0]
    if any(v.shape[0] != dim for v in vecs):
        kept = [(i, v) for i, v in zip(ids, vecs) if v.shape[0] == dim]
        log.warning("特征库维度不一致：保留 %d/%d 条（dim=%d）", len(kept), len(ids), dim)
        if not kept:
            return [], info
        ids = [i for i, _ in kept]
        vecs = [v for _, v in kept]
        info["ids"] = ids
        info["indexed"] = len(ids)
    q = np.asarray(query, dtype=np.float32).reshape(-1)
    if q.shape[0] != dim:
        log.warning("查询向量维度 %d 与特征库 %d 不一致，本次检索跳过", q.shape[0], dim)
        return [], info

    mat = np.stack(vecs)                                  # [N, D]
    q = q.reshape(1, -1)
    sims = (mat @ q.T).reshape(-1)                        # 向量已 L2 归一化，点积即余弦
    sims = np.nan_to_num(sims, nan=0.0, posinf=0.0, neginf=0.0)   # 脏向量不污染排序

    name_by_id = {c.id: c.name for c in cats}
    photo_by_id = {c.id: (c.photos[0] if c.photos else "") for c in cats}

    # 先按阈值筛，再排序 —— 否则边界候选占满 top_n，把真正像的挤出去
    order = [i for i in np.argsort(-sims) if float(sims[i]) >= config.MIN_SIM][:top_n]
    info["dropped"] = len(ids) - len(order) if len(order) < len(ids) else 0
    out = []
    for rank, i in enumerate(order):
        cid = ids[i]
        s = float(sims[i])
        score = to_grade(s)

        # Top1 若与次名拉不开差距，说明这几只猫在当前图上长得一样，
        # 压低分数让上层走“人工确认”，而不是给个高分误导用户直接点确认。
        if rank == 0 and len(order) > 1:
            gap = s - float(sims[order[1]])
            if gap < GAP_CLEAR:
                score = int(score * (0.5 + 0.5 * max(0.0, gap) / GAP_CLEAR))

        out.append({
            "catId": cid,
            "name": name_by_id.get(cid, ""),
            "avatar": photo_by_id.get(cid, ""),
            "score": score,
            "rawSim": round(s, 4),
            "reason": f"特征相似度 {s * 100:.1f}%",
        })
    return out, info


# ---------------- 接口 ----------------
@app.get("/health")
def health():
    """健康检查 / 部署自查。

    除了「服务活着」，这里要能回答现场最常问的三个问题：
      ① 特征库里到底有几只猫（indexed）—— 库里只有 1 只时，识别必然永远返回那 1 只；
      ② 猫体检测有没有启用（detector）—— 没启用就是整图提特征，背景会污染向量；
      ③ 毛色/花纹属性走的是哪条路（attrSource）—— clip 最准、heuristic 是本地
         色域分析的兜底。attrs 为 false 只代表「CLIP 没开」，**花色照样有**，
         因为启用了启发式（2026-10-17 起）。
    这四个字段直接对应「识别不准」的几大成因，排查时不用翻代码。
    """
    eng = get_engine()
    det = getattr(eng.detector, "path", "") or ""
    return {
        "ok": True,
        "provider": eng.provider,
        "dim": eng.dim,
        "size": eng.embedder.size,          # 模型实际接受的输入边长（可能与配置不同）
        "detector": bool(eng.detector.sess),
        # 检测模型用的是哪个文件（自动发现还是显式配置）、阈值、外扩比例。
        # 「detector=true 但框得不准」时，先确认这里指向的是不是预期的那份权重。
        "detectModel": os.path.basename(det) if det else "",
        "detectSize": getattr(eng.detector, "size", 0),
        "detectConf": config.DETECT_CONF,
        "detectPad": config.DETECT_PAD,
        "attrs": bool(eng.clf.ok),
        "attrSource": eng.attr_source,      # clip / api / heuristic —— 属性实际来源
        "minSim": config.MIN_SIM,
        "identifyMin": config.IDENTIFY_MIN,
        "framesMax": config.MAX_FRAMES,
        "ffmpeg": media.ffmpeg_ok(),
        **index_health(),   # indexed / indexBackend，异常时降级为 indexed=-1 + indexError
    }


@app.post("/v1/recognize")
def recognize(req: RecognizeReq, _=Depends(authorize)):
    t0 = time.time()
    eng = get_engine()
    if not req.url and not req.videoUrl:
        raise HTTPException(status_code=400, detail="url or videoUrl required")

    n_frames = max(1, min(config.MAX_FRAMES, int(req.frames or 1)))
    frames: List = []

    if req.type == "video" and req.videoUrl and media.ffmpeg_ok():
        frames = media.extract_frames(req.videoUrl, n_frames)
        log.info("抽帧 %d 张", len(frames))

    if not frames:
        im = media.fetch_image(req.url)
        frames = [im] if im is not None else []

    if not frames:
        raise HTTPException(status_code=502, detail="素材下载失败")

    # 补库放在提特征之前。**不传 skip_ids** —— 早期传的是 req.cats[0].id，
    # 而 req.cats 是「全库猫列表」，第 0 只跟本次上传的照片毫无关系；
    # 结果全库第一只猫永远被跳过、永远补不进库。
    # 幂等由 _ensure_index_inner 里的 index_store.get(c.id) 保证，不需要额外跳过。
    #
    # ⚠️ 硬预算 + 限量：云函数给识别接口的窗口只有 ~1.8s（见 vision.js 的
    # AI_POLL_CAP_MS）。早期这里 limit=40 且不限时，一次请求顺手补十几只猫
    # （每只一次图片下载，超时上限 15s），响应被拖到几十秒 —— 现场实测 78s，
    # 云函数侧必然超时、重试、最终降级本地引擎，用户看到的就是「识别不准」。
    # 现在：最多补 2 只、最多 1.2s，没补完的下次接着补（幂等）。
    t_boot = time.time()
    built_now = ensure_index(
        [c for c in req.cats if c.photos],   # 只对本次真带了照片的猫动手
        req.schoolId,
        limit=int(os.getenv("BOOTSTRAP_LIMIT", "2")),
        budget_ms=int(os.getenv("BOOTSTRAP_BUDGET_MS", "1200")),
    )
    boot_ms = int((time.time() - t_boot) * 1000)

    # 检测 + 提取 + 花色，三步都在 engine.analyze_frames 里：
    #   检测只跑一次（多帧复用同一个框）、逐帧提特征后平均再归一化、
    #   花色取置信度最高的那一帧。为什么这么切，见 analyze_frames 的 docstring。
    # 放在这里调用而不是内联，是为了让「每帧都检测」这类退化能被单测抓住 ——
    # 它不会报错，只会悄悄多花 N×65ms 并让多帧平均失去意义。
    analysis = eng.analyze_frames(frames)
    embs, detected = analysis["embs"], analysis["detected"]
    embed_ms = analysis["timing"]["embed"]
    detect_ms = analysis["timing"]["detect"]

    attrs = analysis["attr"] or {
        "color": "", "pattern": "", "breed": "", "confidence": 0.0,
        "source": "", "palette": [], "stripe": 0.0,
        "reason": "画面里没有可用于判断花色的区域",
    }
    color, pattern = attrs["color"], attrs["pattern"]

    query = l2(np.mean(np.stack(embs), axis=0))
    t_search = time.time()
    candidates, sinfo = search(query, req.cats, req.schoolId)
    search_ms = int((time.time() - t_search) * 1000)

    tags = []
    # 品种（花色类型）放最前：它是「一眼看到的结论」，毛色/花纹是拆解。
    # 三个值各自走对应的中文表：color 用前端枚举的中文（纯白/橘猫/三花…），
    # pattern 用纹理的中文（虎斑条纹/纯色…）—— 混用会导致界面出现 "solid"。
    if attrs["breed"]:
        tags.append({"k": "品种", "v": attrs["breed"]})
    if color:
        tags.append({"k": "毛色", "v": attr_labels.COLOR_LABELS.get(color, color)})
    if pattern:
        tags.append({"k": "花纹", "v": attr_labels.PATTERN_LABELS.get(pattern, pattern)})
    # 「整图」不是中性信息：它意味着没做猫体裁剪，背景会污染特征向量，
    # 这时结果的可信度明显低于「已定位猫体」。措辞要把这层风险带出去。
    tags.append({"k": "检测", "v": "已定位猫体" if detected else "整图（未裁剪）"})
    tags.append({"k": "帧数", "v": str(len(frames))})

    # 属性（毛色/花纹）现在恒可用：CLIP 没开会落到 app/attrs.py 的色域分析。
    # attrs_ready 保留旧语义（CLIP 是否启用），attr_source 说明实际走的哪条路，
    # 排查时能区分「模型判的」和「数像素算的」。
    attrs_ready = bool(eng.clf.ok)

    # 身份是否认得出来。低于 IDENTIFY_MIN（默认 50 分）时前端把文案从
    # 「这是某某」改成「没认出来，但看起来是……」，属性照常展示 ——
    # 这正是「没识别上就调特征识别」这个需求的落点。
    identified = bool(candidates) and candidates[0]["score"] >= config.IDENTIFY_MIN

    total_ms = int((time.time() - t0) * 1000)
    # 分段耗时进日志：现场排查「为什么这个请求 78 秒」时，只有总耗时等于没信息。
    # 五个数字一眼就能定位是补库下载、检测、模型推理、还是特征库读取卡住。
    # 末尾带上花色结论与来源，排查"上传白猫判成橘"时不用再翻响应体。
    log.info("/v1/recognize %dms（补库%d/%dms 检测%dms 推理%dms 检索%dms 帧%d 候选%d 库%d）"
             " 检测=%s 花色=%s/%s(%s %.2f)%s",
             total_ms, built_now, boot_ms, detect_ms, embed_ms, search_ms,
             len(frames), len(candidates), sinfo["indexed"],
             ("%s@%.2f" % (analysis["box"], analysis["detectConf"])) if detected
             else ("未框到：" + (analysis["detectReason"] or "未知")),
             color or "-", pattern or "-", attrs["source"] or "-", attrs["confidence"],
             " 未采信：" + attrs["reason"] if attrs["reason"] else "")

    return {
        "features": {
            "tags": tags,
            "pattern": pattern,
            "color": color,
            "breed": attrs["breed"],
            "size": "",
            # 注意这是**属性置信度**（花色判得有多确定），不是身份匹配分。
            # 两者不要混：身份分在 candidates[].score。
            "confidence": round(float(attrs["confidence"] or 0), 3),
            "attrSource": attrs["source"],
            "embedding": query.astype(float).tolist(),
        },
        "candidates": candidates,
        "meta": {
            "provider": eng.provider,
            "frames": len(frames),
            "latency": total_ms,
            # 分段耗时（毫秒）—— 客户端日志里带上它，定位慢在哪一步不用翻服务端日志
            "timing": {"bootstrap": boot_ms, "detect": detect_ms,
                       "embed": embed_ms, "search": search_ms},
            # 诊断三件套（云函数必须消费 indexedIds，见 search 的 docstring）：
            "indexed": sinfo["indexed"],          # 特征库里有多少只猫
            "indexedIds": sinfo["ids"],           # 具体是哪几只 —— 云函数只标记它们
            "indexedBuilt": built_now,            # 本次请求现建了几只
            "dropped": sinfo["dropped"],          # 因相似度不足被挡掉的候选数
            "minSim": config.MIN_SIM,
            # 身份是否认得出来：false 时前端应展示「没认出是哪只，但看起来是…」，
            # 而不是给一个 20% 的候选当结论。
            "identified": identified,
            "identifyMin": config.IDENTIFY_MIN,
            "attrs": attrs_ready,                 # CLIP 是否启用（旧语义，保留兼容）
            "attrSource": attrs["source"],        # 实际来源：clip / api / heuristic / ''
            "attrConfidence": attrs["confidence"],
            "attrPalette": attrs["palette"],      # 各色占比，排查"为什么判成灰色"用
            "attrReason": attrs["reason"],        # 判不出来时的原因，空 = 正常
            "detector": bool(eng.detector.sess),  # 猫体检测模型是否可用
            # 检测诊断：crop 用的框、检测置信度、候选框数、没框到的原因。
            # 现场「这张图明明有猫却没裁」时，看这一个字段就能分清是
            # 模型没看到（reason=模型没有识别到猫体）、框退化、还是根本没启用。
            "crop": analysis["box"],
            "detectConf": analysis["detectConf"],
            "detectCandidates": analysis["detectCandidates"],
            "detectReason": analysis["detectReason"],
            **index_health(req.schoolId),
        },
    }


@app.get("/v1/index/ids")
def index_ids(schoolId: str = "", _=Depends(authorize)):
    """列出特征库里**真实存在**的猫 id。

    管理端「哪些档案还没录入」必须查这里，不能信云库的 `cats.aiIndexAt`：
    那只是云函数侧的乐观记账，服务端补库失败时它照样有值（2026-10-17 修过这个 bug，
    但存量数据里仍有被误标的猫）。以特征库为准才能看到真相。

    特征库读不出来时返回 503，让管理端明确显示「查不到」，
    而不是返回空列表被误读成「一只都没入库」。
    """
    try:
        return {
            "ok": True,
            "ids": index_store.ids(schoolId),
            "total": index_store.count(schoolId),
            "backend": index_store.BACKEND_NAME,
        }
    except Exception as e:  # noqa: BLE001 —— 后端不可用要显式，不能伪装成空库
        err = "%s: %s" % (type(e).__name__, e)
        log.error("特征库 id 列表读取失败: %s", err)
        raise HTTPException(status_code=503, detail="特征库不可用：" + err)


@app.post("/v1/embed")
def embed(req: EmbedReq, _=Depends(authorize)):
    """单独抽向量，供建库脚本 / 调试用。"""
    im = media.fetch_image(req.url)
    if im is None:
        raise HTTPException(status_code=502, detail="图片下载失败")
    e, detected, a = get_engine().features_ex(im)
    return {"embedding": e.astype(float).tolist(), "dim": int(e.shape[0]),
            "color": a["color"], "pattern": a["pattern"], "breed": a["breed"],
            "attrSource": a["source"], "attrConfidence": a["confidence"],
            "attrPalette": a["palette"], "attrReason": a["reason"],
            "detected": detected}


class BuildReq(BaseModel):
    schoolId: str = ""
    cats: List[CatRef] = Field(default_factory=list)
    photosPerCat: int = 6
    # 只补「特征库里还没有」的猫。定时任务 / 识别热路径增量补库传 true：
    # 已入库的猫直接跳过，既不重复下载也不重算，整批几乎零开销。
    onlyMissing: bool = False
    # 强制重算（手动「全量重建」时用），优先级高于 onlyMissing。
    force: bool = False


@app.post("/v1/index/build")
def build(req: BuildReq, _=Depends(authorize)):
    """批量建库：把档案里每只猫的若干张照片平均成一个「代表向量」存起来。

    多张照片平均出来的代表向量比单张稳得多 —— 同一只猫正面 / 侧面 / 光线差异会被抹平一部分。

    onlyMissing=True 时幂等：特征库里已有向量的猫整只跳过（连照片都不下载），
    所以每天跑一次定时全量建库的成本 ≈ 只建当天新增的猫。
    """
    eng = get_engine()
    ok, fail, skipped = 0, [], 0
    for c in req.cats:
        if req.onlyMissing and not req.force and index_store.get(c.id) is not None:
            skipped += 1
            continue
        embs = []
        for u in c.photos[: max(1, req.photosPerCat)]:
            im = media.fetch_image(u)
            if im is None:
                continue
            e, _, _, _, _ = eng.features(im)
            embs.append(e)
        if not embs:
            fail.append(c.id)
            continue
        rep = l2(np.mean(np.stack(embs), axis=0))
        index_store.put(c.id, req.schoolId, rep, source="build")
        ok += 1
    return {
        "ok": True, "built": ok, "failed": fail, "skipped": skipped,
        "total": index_store.count(req.schoolId),
    }


@app.delete("/v1/index")
def clear_index(schoolId: str = "", _=Depends(authorize)):
    """清空特征库（整体重建前调用）。

    schoolId 为空清空全部；否则只清该校区。配合 /v1/index/build 可实现
    「档案库即真相来源」——新增 / 改名 / 删猫后整体同步一次即完全一致。
    """
    removed = index_store.clear(schoolId)
    return {"ok": True, "removed": removed, "remaining": index_store.count(schoolId)}
